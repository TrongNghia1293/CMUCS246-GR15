/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quanlidatve;

/**
 *
 * @author hoangtrongnghia
 */
public class QuanLiDatVe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        main dn = new main();
        dn.setVisible(true);
    }
    
}
